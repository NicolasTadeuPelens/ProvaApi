import Express  from "express";

const app = Express()
app.use(Express.json())

//================PORTA DO SERVIDOR==================
app.listen(3000, () => {
    console.log("Servidor rodando na porta 3000");
});
//===================================================



//=============USUÁRIOS===============
const users = []

//--GET USUARIO
app.get('/users', (req, res) => {
    res.json({users});
});
//--GET USUARIO POR ID
app.get('/users/:idUsers', (req, res) => {
    const idUsers = req.params.idUsers;
    console.log(idUsers);
    
    const indiceUser = users.findIndex(users => users.id == idUsers);
    if (indiceUser < 0) {
        res.json({ mensagem: "Usuário não existe." });
        return;
    }
    res.json({usuario: users[indiceUser]});
})
//=================================================================================


//cadastro
app.post('/users', (req, res) => {
    console.log('Cadastro de usuario');
    console.log('Body requisição: ', req.body);
    
    // pegar os dados enviados pelo cliente
    const idUsers = req.body.id;
    const nomeUser = req.body.nome;
    const cpfUser = req.body.cpf;
    const emailUser = req.body.email;

    console.log('Id aluno:', idUsers);
    console.log('Nome aluno:', nomeUser);
    console.log('Nome aluno:', cpfUser);
    console.log('Nome aluno:', emailUser);

    const validaemail = /.+@.+\..+/;

    if(nomeUser.length <=2){
        res.json({ mensagem: 'Usuário não cadastrado - Nome deve conter no mínimo 3 caractere'})
    }else if(nomeUser.length >=100){
        res.json({ mensagem: 'Usuário não cadastrado - Nome deve conter no máximo 100 caracteres'})
    }else if(cpfUser.length != 11){
        res.json({ mensagem: 'Usuário não cadastrado - Cpf deve conter 11 caracteres' })
    }else if(idUsers <= 0){
        res.json({ mensagem: 'Usuário não cadastrado - Código deve ser maior que 0' })
    }else if(emailUser.length <=3){
        res.json({ mensagem: 'Usuário não cadastrado - Email deve conter no mínimo 3 caracteres' })
    }else if(emailUser.length >=100){
        res.json({ mensagem: 'Usuário não cadastrado - Email deve conter no máximo 100 caracteres' })
    }else if(validaemail.test(emailUser) != true){
        res.json({ mensagem: 'Usuário não cadastrado - Email deve conter @' })
    }else{        
        // salvar na lista de usuarios
        const Usuario = {
            id: idUsers,
            nome: nomeUser,
            cpf: cpfUser,
            email: emailUser,
        };
        users.push(Usuario);
        res.json({ mensagem: 'Usuário cadastrado.' });
    }

});
//=================================================================================


//deleta usuario pelo id
app.delete('/users/:idUsers', (req, res) => {
    // pegar o id do usuário
    const idUsers = req.params.idUsers;
    console.log(idUsers);

    // remover o usuário da lista
    const indiceUser = users.findIndex(users => users.id == idUsers);
    if (indiceUser < 0) {
        res.json({ mensagem: "Usuário não existe." });
        return;
    }
    users.splice(indiceUser, 1);

    res.json({ mensagem: 'Usuário removido com sucesso' });
});
//=================================================================================


app.put('/users/:id', (req,res) =>{

})

//=============PRODUTO===============
const products = []
//--GET PRODUTO
app.get('/products', (req, res) => {
    res.json({products});
});
//--GET PRODUTO POR ID
app.get('/products/:idProd', (req, res) => {
    const idProd = req.params.idProd;
    console.log(idProd);
    
    const indiceProd = products.findIndex(products => products.id == idProd);
    if (indiceProd < 0) {
        res.json({ mensagem: "Produto não existe." });
        return;
    }
    res.json({produto: products[indiceProd]});
})
//=================================================================================


//cadastro
app.post('/products', (req, res) => {
    console.log('Cadastro de Produto');
    console.log('Body requisição: ', req.body);
    
    // pegar os dados enviados pelo cliente
    const idProd = req.body.id;
    const nomeProd = req.body.nome;
    const priceProd = req.body.price;


    console.log('Id aluno:', idProd);
    console.log('Nome aluno:', nomeProd);
    console.log('Nome aluno:', priceProd);

    
    if(nomeProd.length <=2){
        res.json({ mensagem: 'Produto não cadastrado - Nome deve conter no mínimo 3 caractere'})
    }else if(nomeProd.length >=100){
        res.json({ mensagem: 'Produto não cadastrado - Nome deve conter no máximo 100 caracteres'})
    }else if(priceProd <= 0){
        res.json({ mensagem: 'Produto não cadastrado - Preço deve ser maior que 0' })
    }else if(idProd <= 0){
        res.json({ mensagem: 'Produto não cadastrado - Código deve ser maior que 0' })
    }else{
        // salvar na lista de pordutos
        const Produto = {
            id: idProd,
            nome: nomeProd,
            price: priceProd,
        };
        products.push(Produto);
        res.json({ mensagem: 'Produto cadastrado.' });
    }
    
});
//=================================================================================


//deleta produto pelo id
app.delete('/products/:idProd', (req, res) => {
    // pegar o id do Produto
    const idProd = req.params.idProd;
    console.log(idProd);

    // remover o Produto da lista
    const indiceProd = products.findIndex(products => products.id == idProd);
    if (indiceProd < 0) {
        res.json({ mensagem: "Produto não existe." });
        return;
    }
    products.splice(indiceProd, 1);

    res.json({ mensagem: 'Produto removido com sucesso' });
});
//=================================================================================

app.put('/users/:id', (req,res) =>{

})














